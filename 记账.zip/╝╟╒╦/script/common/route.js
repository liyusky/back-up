var Route = {
  header: {
    type: 'Header',
    url: './header.html'
  },
  bangzhu: {
    type: 'Default',
    url: '../wode/bangzhu.html',
    title: '帮助'
  },
  dingshitixing: {
    type: 'Default',
    url: '../wode/dingshitixing.html',
    title: '定时提醒'
  },
  guanyulanqian: {
    type: 'Default',
    url: '../wode/guanyulanqian.html',
    title: '关于记账'
  },
  yijianfankui: {
    type: 'Default',
    url: '../wode/yijianfankui.html',
    title: '意见反馈'
  },
  ershoujiaoyi: {
    type: 'Default',
    url: '../faxian/link/ershoujiaoyi.html',
    title: '二手交易'
  },
  huilvchaxun: {
    type: 'Default',
    url: '../faxian/link/huilvchaxun.html',
    title: '汇率查询'
  },
  kuaidichaxun: {
    type: 'Default',
    url: '../faxian/link/kuaidichaxun.html',
    title: '快递查询'
  },
  weizhangchaxun: {
    type: 'Default',
    url: '../faxian/link/weizhangchaxun.html',
    title: '违章查询'
  },
  empower: {
    type: 'Cover',
    url: '../shouquan/empower.html'
  }
}
